package tareaCurso;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DataFormat;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class Registro extends Excel {
	
	public Registro(String rutacrear) {
		super(rutacrear);
		
	}

	public  void Registrar() {
	
		try {
			
	        FileInputStream f = new FileInputStream(rutacrear);
	        Workbook workbook = WorkbookFactory.create(f);
	        Sheet sheet = workbook.getSheetAt(0);

	        Scanner tc = new Scanner(System.in);

	        int codigo =0;
	       
	        	try {
	        		 do {
	        		 System.out.println("Ingrese el código del producto");
	     	        
	    	         codigo = tc.nextInt();
	    	        tc.nextLine();
	        		 } while (codigo<=0);
				} catch (java.util.InputMismatchException i) {
					System.out.println("Error dato invalido");
					System.out.println("Volviendo al Menu...");
			   		inicio op = new inicio();
			   		op.setVisible(true);
			   		return;
				}
	       
	       
	       
	        int cantidad=0;
	        try {
	        do {
	        System.out.print("Ingrese la cantidad: ");
	         cantidad = tc.nextInt();
	        tc.nextLine();
	        } while (cantidad<=0);
	    	} catch (java.util.InputMismatchException i) {
				System.out.println("Error dato invalido");
				System.out.println("Volviendo al Menu...");
		   		inicio op = new inicio();
		   		op.setVisible(true);
		   		return;
			}
	       
	        boolean productoExistente = false;
	      
	        for (Row row : sheet) {
	            Cell codigoCell = row.getCell(0);
	            if (codigoCell != null && codigoCell.getCellType() == CellType.NUMERIC) {
	                int codigoExistente = (int) codigoCell.getNumericCellValue();
	                if (codigoExistente == codigo) {
	                    // Si el producto existe solo se actualiza la cantidad
	                    Cell cantidadCell = row.getCell(2);
	                    if (cantidadCell != null && cantidadCell.getCellType() == CellType.NUMERIC) {
	                        double cantidadExistente = cantidadCell.getNumericCellValue();
	                        cantidadExistente = cantidadExistente + cantidad;
	                        cantidadCell.setCellValue(cantidadExistente);
	                        productoExistente = true;
	                        break;
	                    }
	                }
	            }
	        }

	        if (!productoExistente) {
	           
	        	
	        	 System.out.print("Ingrese el nombre: ");
	             String nombre = tc.nextLine();
	             float precio=0; 
	             
	             try {
	             do {
	             System.out.println("Ingrese el precio: ");
	              precio = tc.nextFloat();
	             } while (precio<=0);
	         	} catch (java.util.InputMismatchException i) {
					System.out.println("Error dato invalido");
					System.out.println("Volviendo al Menu...");
			   		inicio op = new inicio();
			   		op.setVisible(true);
			   		return;
				}
	             int decimalPlaces = 2;

	             precio = Math.round(precio * (float) Math.pow(10, decimalPlaces)) / (float) Math.pow(10, decimalPlaces);
	             
	             int filaUltima = sheet.getLastRowNum();
	            Row newRow = sheet.createRow(filaUltima + 1);
	            Cell cellCod = newRow.createCell(0);
	            cellCod.setCellValue(codigo);
	            Cell cellNombre = newRow.createCell(1);
	            cellNombre.setCellValue(nombre);	
	            Cell cellCantidad = newRow.createCell(2);
	            cellCantidad.setCellValue(cantidad);
	            Cell cellPrecio = newRow.createCell(3);
                cellPrecio.setCellValue(precio);
	        }

            CellStyle currencyStyle = workbook.createCellStyle();
            DataFormat dataFormat = workbook.createDataFormat();
            currencyStyle.setDataFormat(dataFormat.getFormat("[$$-409]#,##0.00"));

            int precioColumna = 3;
            int ColumnaCantidad = 2;
       
            
            for (Row row : sheet) {
                Cell cell = row.getCell(precioColumna);
                if (cell != null) {
                    cell.setCellStyle(currencyStyle);
                }
            }

            Row row = sheet.getRow(0);
            
            CellStyle hS = workbook.createCellStyle();
            hS.setFillForegroundColor(IndexedColors.GREEN.getIndex());
    	    hS.setFillPattern(FillPatternType.SOLID_FOREGROUND);
    	    Font hF = workbook.createFont();
    	    hF.setColor(IndexedColors.WHITE.getIndex());
    	    hS.setFont(hF);
    	    
            Cell cellPrecio = row.getCell(3);
            cellPrecio.setCellStyle(hS);
            
            
            sheet.autoSizeColumn(precioColumna);
            sheet.autoSizeColumn(ColumnaCantidad);
            sheet.autoSizeColumn(1);
	        

	        try (FileOutputStream outputStream = new FileOutputStream(rutacrear)) {
	            workbook.write(outputStream);
	            System.out.println("Datos registrados exitosamente en el archivo de Excel.");
	        } catch (IOException e) {
	            e.printStackTrace();
	        } finally {
	            workbook.close();
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
		Scanner tc = new Scanner(System.in);
		inicio op = new inicio();
		System.out.println("Presione cualquier tecla para regresar al inicio");
		String aux = tc.nextLine();
		System.out.println("Regresando...");
		op.setVisible(true);
	}

}

