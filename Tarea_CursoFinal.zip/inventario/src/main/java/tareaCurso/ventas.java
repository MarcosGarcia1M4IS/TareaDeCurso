package tareaCurso;

import java.util.ArrayList;


import org.apache.poi.ss.usermodel.*;
import java.util.Calendar;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import java.io.File;
import java.io.FileInputStream;
public class ventas extends Excel {
	
	public ventas(String rutacrear) {
		super(rutacrear);
		// TODO Auto-generated constructor stub
	}

	int contador=0;
	int contador2=0;
	boolean venta = false;
	int opc;
	boolean encontrar= false;

    public void vender() {
    	
        int tamaño = 0;
        String[][] arr = new String[10][4];

        while (opc != 2) {
            try {
                FileInputStream fis = new FileInputStream(rutacrear);
                Workbook workbook = WorkbookFactory.create(fis);
                Sheet sheet = workbook.getSheetAt(0);

                Scanner scanner = new Scanner(System.in);

                
                boolean excelVacio = (sheet.getLastRowNum() <= 0);

                if (excelVacio) {
                    System.out.println("El archivo de Excel está vacío.");                  
                    System.out.println("Volviendo al Menu...");
               		inicio op = new inicio();
               		op.setVisible(true);
               		return;
                }
                int codigo;
                try {
                System.out.println("Ingrese el código del producto");
                 codigo = scanner.nextInt();
                scanner.nextLine();
                } catch (java.util.InputMismatchException i) {
					System.out.println("Error dato invalido");
					System.out.println("Volviendo al Menu...");
			   		inicio op = new inicio();
			   		op.setVisible(true);
			   		return;
				}
                
                int cantidad =0;
                
                try {
				do {
                System.out.print("Ingrese la cantidad que desea vender: ");
                 cantidad = scanner.nextInt();
                scanner.nextLine();
				} while (cantidad<=0);
                } catch (java.util.InputMismatchException i) {
					System.out.println("Error dato invalido");
					System.out.println("Volviendo al Menu...");
			   		inicio op = new inicio();
			   		op.setVisible(true);
			   		return;
				}
				
				
				
                boolean productoExistente = false;
                String nombre = null;
                double precio = 0;
                

                for (Row row : sheet) {
                    Cell codigoCell = row.getCell(0);
                    if (codigoCell != null && codigoCell.getCellType() == CellType.NUMERIC) {
                        int codigoExistente = (int) codigoCell.getNumericCellValue();

                        if (codigoExistente == codigo) {
                            // El producto ya existe, verificar la cantidad disponible
                            Cell cantidadCell = row.getCell(2);
                            Cell nombreCell = row.getCell(1);
                            Cell precioCell = row.getCell(3);
                            if ( precioCell != null && precioCell.getCellType() == CellType.NUMERIC) {
                            	 precio =   precioCell.getNumericCellValue();
                            }
                            if (nombreCell != null && nombreCell.getCellType() == CellType.STRING ) {
                                nombre = nombreCell.getStringCellValue();
                               
                            } else {
                                nombre = ""; // o asigna un valor predeterminado en caso de que la celda no contenga una cadena
                            }

                            if (cantidadCell != null && cantidadCell.getCellType() == CellType.NUMERIC) {
                                double cantidadExistente = cantidadCell.getNumericCellValue();
                                if (cantidadExistente >= cantidad) {
                                    cantidadExistente -= cantidad;
                                    cantidadCell.setCellValue(cantidadExistente);
                                    productoExistente = true;
                                } else {
                                    System.out.println("No hay suficiente cantidad del producto para realizar la venta.");
                                   
                                }
                                break;
                            }
                        }
                    }
                }

                boolean existe = true;

                if (!productoExistente) {
                    System.out.println("Error: Este producto no se encontró en el inventario.");
                    existe = false;
                    inicio op = new inicio();
               		op.setVisible(true);
                    break;
                }

                if (existe) {
                    // Guardar los datos de la venta en la matriz
                    arr[tamaño][0] = String.valueOf(codigo);
                    arr[tamaño][1] = nombre;
                    arr[tamaño][2] = String.valueOf(cantidad);
                    arr[tamaño][3] = String.valueOf(precio);
                    contador++;
                    tamaño++;

                    

                    imprimirFactura(arr);
                    try (FileOutputStream outputStream = new FileOutputStream(rutacrear)) {
                        workbook.write(outputStream);
                        System.out.println("Datos registrados exitosamente en el archivo de Excel.");
                        venta=true;
                        
                        try {
                        System.out.println("\nDesea realizar otra venta?\n1.Si\n2.No");
                        opc = scanner.nextInt();
                        } catch (java.util.InputMismatchException i) {
        					System.out.println("Error dato invalido");
        					System.out.println("Volviendo al Menu...");
        			   		inicio op = new inicio();
        			   		op.setVisible(true);
        			   		return;
        				}
                        if (opc == 1) {
                            if (tamaño >= arr.length) {
                                // Expandir la matriz 
                            	  String[][] temp = new String[arr.length + 10][3];
  	                            System.arraycopy(arr, 0, temp, 0, arr.length);
  	                            arr = temp;
                            }
                        }
                           if (opc == 2) {
                        	//Regresar a la Intefaz de Inicio
                       		System.out.println("Volviendo al Menu...");
                       		inicio op = new inicio();
                       		op.setVisible(true);
                       	    return; 
                           }
                        
	                } catch (IOException e) {
	                    e.printStackTrace();
	                } finally {
	                    workbook.close();
	                }
	            }
	            
	            
	            
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }

	
	}
	
	public void imprimirFactura(String[][] arr) {
		if (opc!=2) {
		Calendar Hora = Calendar.getInstance();
		Calendar fecha = Calendar.getInstance();
		
		
		contador2++;
		int hora,minutos,seg,dia,mes,anno;
		String hora_actual,fecha_actual;
		hora = Hora.get(Calendar.HOUR_OF_DAY);
		minutos= Hora.get(Calendar.MINUTE);
		seg = Hora.get(Calendar.SECOND);
		dia = fecha.get(Calendar.DATE);
		mes= fecha.get(Calendar.MONTH);
		anno= fecha.get(Calendar.YEAR);
		fecha_actual=dia+":"+(mes+1)+":"+anno;
		hora_actual = hora+":"+minutos+":"+seg;
		
	    System.out.println("--------------------FACTURA-------------------------------------------------------");
	    System.out.println("----------------------------------------------------------------------------------");
	    System.out.println("Hora: "+hora_actual);
	    System.out.println("----------------------------------------------------------------------------------");
	    System.out.println("Fecha: "+fecha_actual);
	    System.out.println("----------------------------------------------------------------------------------");
	    System.out.println("Código \t\tNombre \t\tCantidad \t\tPrecio \t\tTotal");
	    System.out.println("----------------------------------------------------------------------------------");
	    
	    for (int i = 0; i < arr.length; i++) {
	        String codigo = arr[i][0];
	        String nombre = arr[i][1];
	        String cantidad = arr[i][2];
	        String precio = arr[i][3];
	        
	        
	        if (codigo != null && nombre != null && cantidad != null && precio != null) {
                double cantidadValue = Double.parseDouble(cantidad);
                double precioValue = Double.parseDouble(precio);
                double total = cantidadValue * precioValue;
             
                String totalFormateado;
                
                    totalFormateado = String.format("%.4f", total);
                
                
              
                
                System.out.printf("%-10s \t%-15s \t%s \t\t$%.4s \t\t%s%n", codigo, nombre, cantidad, precio, totalFormateado);

             
	        }
	    }
	    
	    System.out.println("----------------------------------------------------------------------------------");
	    System.out.println("¡Gracias por su compra!");
		} else 
			System.out.println("");
		opc=0;
	}

}
	
	


