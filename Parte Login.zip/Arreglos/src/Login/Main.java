package Login;

public class Main {

	public static void main(String[] args) {
		
		LoginP op = new LoginP (123, 0, "hola", null);
		
		op.usuario();

	}

}
