package Login;

import java.util.Scanner;

public class LoginP {
	
	int password = 123;
	int pass;
	String Usuario = "hola";
	String usu=null;
	int contador=0,contador2=0;
	
	
	Scanner tc = new Scanner (System.in);
	public LoginP(int password, int pass, String usuario, String usu) {
		this.password = password;
		this.pass = pass;
		Usuario = usuario;
		this.usu = usu;
	}
	
	public void usuario () {
		System.out.println("Hola bienvenido, ingrese por favor su nombre de usuario");
		usu=tc.nextLine();
		do {
			if (!Usuario.equals(usu.toLowerCase())) {
			System.out.println("Usuaro incorrecto ingreselo de nuevo");
			usu=tc.nextLine();
			contador++;
		} 
		}while (!Usuario.equals(usu.toLowerCase()) && contador<=3);
		
		if (Usuario.equals(usu.toLowerCase())) {
			System.out.println("Bienvenido de nuevo ingrese por favor la contraseña");
			pass=tc.nextInt();
			do {
				if (password!=pass) {
				System.out.println("Contraseña incorrecta ingreselo de nuevo");
				pass=tc.nextInt();
				contador2++;
			} 
			}while (password!=pass && contador2<=3);
			
			if (password==pass) {
				System.out.println("Felicidades");
			}
			
		}
		if (contador>=3 || contador2 >=3) {
			System.out.println("Intentos agotados");
			System.exit(contador);
		}
		
	}
	
}


