package Login;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
		try {
			
			Scanner tc = new Scanner (System.in);
			LoginP op = new LoginP(123, 0, "hola", null);
			LoginV op2 = new LoginV (2221, 0, "vendedores", null);
			int opc;
			
			
			
			System.out.println("Escriba N°1 Para gerente \nN°2 Para vendedores");
			opc=tc.nextInt();
			
	
		
		
		switch (opc) {
		
		case 1:
			op.usuario();
			
			
		break;	
			
		case 2 :
		op2.usuario();
		break;
		
		default :
System.out.println("Error opcion invalida");		
		
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		} catch (java.util.InputMismatchException e) {
			System.out.println("ERROR DATO INVALIDO");
		}

	}

}
