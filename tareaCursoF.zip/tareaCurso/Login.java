package tareaCurso;
import java.util.Scanner;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JPasswordField;
import javax.swing.UIManager;

public class Login extends JFrame {

	private JPanel contentPane;
	private JTextField usuario;
	private JPasswordField contraseña;
	int cont = 0;

	/**
	 * Launch the application.
	 */


	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login frame = new Login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Login() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(UIManager.getColor("Button.background"));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("Usuario:");
		lblNewLabel_1.setFont(new Font("Arial", Font.PLAIN, 12));
		lblNewLabel_1.setBounds(46, 73, 64, 14);
		contentPane.add(lblNewLabel_1);
		
		usuario = new JTextField();
		usuario.setFont(new Font("Times New Roman", Font.PLAIN, 13));
		usuario.setBounds(46, 98, 111, 20);
		contentPane.add(usuario);
		usuario.setColumns(10);
		
		JLabel lblNewLabel_1_1 = new JLabel("Contraseña:");
		lblNewLabel_1_1.setFont(new Font("Arial", Font.PLAIN, 12));
		lblNewLabel_1_1.setBounds(46, 129, 78, 14);
		contentPane.add(lblNewLabel_1_1);
		
		JButton btnNewButton = new JButton("Iniciar Sesion");
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(usuario.getText().equals("Administrador") && contraseña.getText().equals("Universidad")) {
					dispose();
					JOptionPane.showMessageDialog(null, "Bienvenido", "Ingresaste", JOptionPane.INFORMATION_MESSAGE);
					inicio op = new inicio();
				Archivo op1 = new Archivo();
		        op1.main(null);
					
					op.setVisible(true);
				}else if(usuario.getText().equals("") || contraseña.getText().equals("")){
					JOptionPane.showMessageDialog(null, "Favor, Llenar los Campos de Texto","Casillas Vacías",JOptionPane.ERROR_MESSAGE);
				}else {
					JOptionPane.showMessageDialog(null, "Usuario o Contraseña Incorrectos","Error",JOptionPane.ERROR_MESSAGE);
					usuario.setText("");
					contraseña.setText("");
					usuario.requestFocus();
					contraseña.requestFocus();
					cont++;
				}
				if(cont == 3) {
					JOptionPane.showMessageDialog(null, "Demasiados Intentos Fallidos","Cerrando Programa...",JOptionPane.ERROR_MESSAGE);
					dispose();
				}
				
			}
		});
		btnNewButton.setFont(new Font("Arial", Font.PLAIN, 12));
		btnNewButton.setBounds(46, 185, 111, 23);
		contentPane.add(btnNewButton);
		
		contraseña = new JPasswordField();
		contraseña.setFont(new Font("Times New Roman", Font.PLAIN, 13));
		contraseña.setBounds(46, 154, 111, 20);
		contentPane.add(contraseña);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(79, 160, 174));
		panel.setBounds(0, 0, 434, 60);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Login de Usuario");
		lblNewLabel.setForeground(new Color(255, 255, 255));
		lblNewLabel.setBounds(128, 11, 190, 36);
		panel.add(lblNewLabel);
		lblNewLabel.setFont(new Font("Arial", Font.PLAIN, 24));
	}
}
