package tareaCurso;

import java.awt.EventQueue;
import java.io.File;

import javax.swing.JOptionPane;

public class Archivo extends inicio{
	public static void main(String[] args) {
		
		rutacrear = JOptionPane.showInputDialog("Escribe la dirección del archivo que deseas abrir: ");

		if (rutacrear == null) {
			System.out.println("No ha dado ninguna ruta");
			System.exit(0);
			
		}else {
			File file = new File(rutacrear);
		    if (file.exists()) {
		      System.out.println("Archivo Encontrado");
		    }else {
		    	Excel op1 = new Excel(rutacrear);
		    	System.out.println("El archivo Excel no existe");
				op1.crearExcel();
				
		    }
		}
		
	}
}
