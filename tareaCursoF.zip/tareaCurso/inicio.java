package tareaCurso;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.IOException;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class inicio extends JFrame {


	
	private JPanel contentPane;
	
	
	static String rutacrear = "C:\\Users\\Estudiantes\\Documents\\Inventario\\Mercancías.xlsx";   
	
	public inicio(String rutacrear) {
		this.rutacrear = rutacrear;
	}

	public static void main(String[] args)  {
		
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					inicio frame = new inicio();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		
	}

	/**
	 * Create the frame.
	 */
	
	
	public inicio() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(79, 160, 174));
		panel.setBounds(0, 0, 434, 46);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Menu");
		lblNewLabel.setForeground(new Color(255, 255, 255));
		lblNewLabel.setFont(new Font("Arial", Font.PLAIN, 24));
		lblNewLabel.setBounds(184, 11, 81, 24);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("¿Que Desea Realizar?");
		lblNewLabel_1.setFont(new Font("Arial", Font.PLAIN, 16));
		lblNewLabel_1.setBounds(133, 57, 166, 28);
		contentPane.add(lblNewLabel_1);
		
		JButton btnNewButton = new JButton("Ingresar");
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				dispose();
				Registro ope = new Registro(rutacrear);
				ope.Registrar();
			}
		});
		btnNewButton.setBounds(33, 127, 89, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Vender");
		btnNewButton_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				dispose();
				ventas oper = new ventas(rutacrear);
				oper.vender();	
			}
		});
		btnNewButton_1.setBounds(174, 127, 89, 23);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Mostrar");
		btnNewButton_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				dispose();
				Impresion op = new Impresion(rutacrear);
				op.Imprimir();
				}
		});
		btnNewButton_2.setBounds(315, 127, 89, 23);
		contentPane.add(btnNewButton_2);
		
		JButton btnNewButton1 = new JButton("Crear archivo Excel");
		btnNewButton1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				dispose();
				Excel op1 = new Excel(rutacrear);
				op1.crearExcel();
			}
		});
		btnNewButton1.setBounds(43, 194, 150, 23);
		contentPane.add(btnNewButton1);
		
		JButton btnNewButton4 = new JButton("Cargar archivo Excel");
		btnNewButton4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton4.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				dispose();
				Archivo op =new Archivo();
				op.main(null);
				
				  
		   		inicio op3 = new inicio();
		   		op3.setVisible(true);
		   		return;
			    
			}
		});
		btnNewButton4.setBounds(239, 194, 160, 23);
		contentPane.add(btnNewButton4);
	}
	
}



