package Login;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;


public class InventoryRecord {
	 private static Map<String, Integer> inventory = new HashMap<>();

	public static void main(String[] args) {
		
		

		   

		   
		        Scanner scanner = new Scanner(System.in);
		        int choice;

		        do {
		            System.out.println("Sistema de registro de inventario");
		            System.out.println("1. Añadir un articulo");
		            System.out.println("2. Eliminar un articulo");
		            System.out.println("3. Actualizar la cantidad de un articulo");
		            System.out.println("4. Mosstrar inventario");
		            System.out.println("5. Salirr");
		            System.out.print("Introduce un numero: ");
		            choice = scanner.nextInt();

		            switch (choice) {
		                case 1:
		                    addItem(scanner);
		                    break;
		                case 2:
		                    removeItem(scanner);
		                    break;
		                case 3:
		                    updateItemQuantity(scanner);
		                    break;
		                case 4:
		                    displayInventory();
		                    break;
		                case 5:
		                    System.out.println("Saliendo...");
		                    break;
		                default:
		                    System.out.println("Eror dato invalido.Intente de nuevo");
		            }
		        } while (choice != 5);

		        scanner.close();
		    }

		    private static void addItem(Scanner scanner) {
		        System.out.print("Ingrese el nombre del articulo: ");
		        String itemName = scanner.next();
		        System.out.print("Ingrese la cantidad: ");
		        int quantity = scanner.nextInt();

		        if (inventory.containsKey(itemName)) {
		            System.out.println("Este articulo ya existe. actualice la cantidad...");
		            quantity += inventory.get(itemName);
		        }

		        inventory.put(itemName, quantity);
		        System.out.println("Articulo añadido correctamente.");
		    }

		    private static void removeItem(Scanner scanner) {
		        System.out.print("Ingrese el nombre del articulo: ");
		        String itemName = scanner.next();

		        if (inventory.containsKey(itemName)) {
		            inventory.remove(itemName);
		            System.out.println("Articulo removido exitosamente.");
		        } else {
		            System.out.println("Articulo no encontrado en el inventario.");
		        }
		    }

		    private static void updateItemQuantity(Scanner scanner) {
		        System.out.print("Enter item name: ");
		        String itemName = scanner.next();

		        if (inventory.containsKey(itemName)) {
		            System.out.print("Ingrese la nueva cantidad: ");
		            int newQuantity = scanner.nextInt();
		            inventory.put(itemName, newQuantity);
		            System.out.println("Articulo actualizado correctamente.");
		        } else {
		            System.out.println("Articulo no encontrado.");
		        }
		    }

		    private static void displayInventory() {
		        System.out.println("Inventario:");
		        for (Map.Entry<String, Integer> entry : inventory.entrySet()) {
		            System.out.println(entry.getKey() + " - " + entry.getValue());
		        }
		    }
		}

	


