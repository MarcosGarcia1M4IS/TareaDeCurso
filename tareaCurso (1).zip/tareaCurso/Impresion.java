package tareaCurso;

import java.io.File;
import java.io.FileInputStream;
import java.util.Scanner;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class Impresion extends Excel {
	
	
	
	public Impresion(String rutacrear) {
		super(rutacrear);
		
	}

	public void Imprimir() {
		
		try {
			
	        File file = new File(rutacrear);
	        FileInputStream f = new FileInputStream(file);

	        Workbook workbook = WorkbookFactory.create(f);
	        Sheet sheet = workbook.getSheetAt(0); // Se toma la primera hoja

	        // aquí se recorren las filas y columnas de la hoja
	        for (Row row : sheet) {
	            for (Cell cell : row) {
	                String value;
	                if (cell.getCellType() == CellType.STRING) {
	                    value = cell.getStringCellValue();
	                } else if (cell.getCellType() == CellType.NUMERIC) {
	                    value = String.valueOf(cell.getNumericCellValue());
	                } else {
	                    // Otros tipos de celda para que igualmente los imprima
	                    value = cell.toString();
	                }
	                System.out.print(value + "\t"+"\t");
	            }
	            System.out.println();
	        }

	        workbook.close();
	        f.close();
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
		Scanner tc = new Scanner(System.in);
		inicio op = new inicio();
		System.out.println("Presione cualquier tecla para regresar al inicio");
		String aux = tc.nextLine();
		System.out.println("Regresando...");
		op.setVisible(true);
	}

}
