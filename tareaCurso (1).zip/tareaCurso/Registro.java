package tareaCurso;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class Registro extends Excel {
	
	public Registro(String rutacrear) {
		super(rutacrear);
		
	}

	public  void Registrar() {
	
		try {
			
	        FileInputStream f = new FileInputStream(rutacrear);
	        Workbook workbook = WorkbookFactory.create(f);
	        Sheet sheet = workbook.getSheetAt(0);

	        Scanner tc = new Scanner(System.in);

	        System.out.println("Ingrese el código del producto");
	        int codigo = tc.nextInt();
	        tc.nextLine();
	        
	       
	        System.out.print("Ingrese la cantidad: ");
	        int cantidad = tc.nextInt();
	        tc.nextLine();
	       
	       
	        boolean productoExistente = false;
	      
	        for (Row row : sheet) {
	            Cell codigoCell = row.getCell(0);
	            if (codigoCell != null && codigoCell.getCellType() == CellType.NUMERIC) {
	                int codigoExistente = (int) codigoCell.getNumericCellValue();
	                if (codigoExistente == codigo) {
	                    // Si el producto existe solo se actualiza la cantidad
	                    Cell cantidadCell = row.getCell(2);
	                    if (cantidadCell != null && cantidadCell.getCellType() == CellType.NUMERIC) {
	                        double cantidadExistente = cantidadCell.getNumericCellValue();
	                        cantidadExistente = cantidadExistente + cantidad;
	                        cantidadCell.setCellValue(cantidadExistente);
	                        productoExistente = true;
	                        break;
	                    }
	                }
	            }
	        }

	        if (!productoExistente) {
	           
	        	
	        	 System.out.print("Ingrese el nombre: ");
	             String nombre = tc.nextLine();
	             
	             System.out.println("Ingrese el precio: ");
	             float precio = tc.nextFloat();
	            
	             int decimalPlaces = 2;

	             precio = Math.round(precio * (float) Math.pow(10, decimalPlaces)) / (float) Math.pow(10, decimalPlaces);
	             
	             int filaUltima = sheet.getLastRowNum();
	            Row newRow = sheet.createRow(filaUltima + 1);
	            Cell cellCod = newRow.createCell(0);
	            cellCod.setCellValue(codigo);
	            Cell cellNombre = newRow.createCell(1);
	            cellNombre.setCellValue(nombre);	
	            Cell cellCantidad = newRow.createCell(2);
	            cellCantidad.setCellValue(cantidad);
	            Cell cellPrecio = newRow.createCell(3);
                cellPrecio.setCellValue(precio);
	        }

	        
	        

	        // Guardar los cambios en el archivo
	        try (FileOutputStream outputStream = new FileOutputStream(rutacrear)) {
	            workbook.write(outputStream);
	            System.out.println("Datos registrados exitosamente en el archivo de Excel.");
	        } catch (IOException e) {
	            e.printStackTrace();
	        } finally {
	            workbook.close();
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
		Scanner tc = new Scanner(System.in);
		inicio op = new inicio();
		System.out.println("Presione cualquier tecla para regresar al inicio");
		String aux = tc.nextLine();
		System.out.println("Regresando...");
		op.setVisible(true);
	}

}

