package tareaCurso;


import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import java.io.File;
public class Excel {
	
	String rutacrear=" ";
	
	
	public Excel(String rutacrear) {
		this.rutacrear = rutacrear;
	}


	public void crearExcel() {
		
		Scanner tc = new Scanner(System.in); 
	       // Se crea un nuevo libro
	 System.out.println("Ingrese el directorio donde quiere guardar su archivo excel");
	 rutacrear = tc.nextLine();

		File file = new File(rutacrear);
	    if (file.exists()) {
	        System.out.println("El archivo de Excel ya existe en la ruta especificada: " + rutacrear);
	        
	        System.out.println("Volviendo al Menu...");
       		inicio op = new inicio();
       		op.setVisible(true);
       		return;
	      
	    }
	    
		
		Workbook workbook = new XSSFWorkbook();
	    
	    //hoja en el libro
	    Sheet sheet = workbook.createSheet("Hoja1");

	    //fila en la hoja
	    Row row = sheet.createRow(0);

	   
	 
	    CellStyle headerStyle = workbook.createCellStyle();
	    headerStyle.setFillForegroundColor(IndexedColors.GREEN.getIndex());
	    headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

	    Font headerFont = workbook.createFont();
	    headerFont.setColor(IndexedColors.WHITE.getIndex());
	    headerStyle.setFont(headerFont);

	    Cell cell1 = row.createCell(0);
	    cell1.setCellValue("Nro.");
	    cell1.setCellStyle(headerStyle);

	    Cell cell2 = row.createCell(1);
	    cell2.setCellValue("Nombre");
	    cell2.setCellStyle(headerStyle);

	    Cell cell3 = row.createCell(2);
	    cell3.setCellValue("Cantidad");
	    cell3.setCellStyle(headerStyle);

	    Cell cell4 = row.createCell(3);
	    cell4.setCellValue("Precio/Unidad");
	    cell4.setCellStyle(headerStyle);


	    sheet.autoSizeColumn(3);


	    // Guardar el libro de Excel en un archivo de excel
	    String filePath = rutacrear;
	    try (FileOutputStream outputStream = new FileOutputStream(filePath)) {
	        workbook.write(outputStream);
	    } catch (IOException e) {
	        e.printStackTrace();
	    }

	    // Cerrar 
	    try {
	        workbook.close();
	    } catch (IOException e) {
	        e.printStackTrace();
	    }

	    System.out.println("Archivo de Excel creado exitosamente en: " + filePath);
	
	    System.out.println("Volviendo al Menu...");
   		inicio op = new inicio();
   		op.setVisible(true);
   		return;
	    
	}

}
